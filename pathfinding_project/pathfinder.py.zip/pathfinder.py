from array import array
from multiprocessing import Array
import random




def generate_grid():
    rows=5
    cols=5
    grid = [[random.randint(1,100) for  i in range (rows)] for j in range(cols)]
    return grid




grid=generate_grid()
for i in grid:
    print(i)


stable_grid=[[35, 7, 92, 66, 9], [27, 37, 44, 34, 93], [80, 8, 57, 51, 32], [26, 61, 38, 37, 60], [55, 34, 75, 76, 74]]

class path:
    possible_path =[]
    weight=0
    def __init__(self,input_path,input_weight):
        self.possible_path = input_path
        self.weight=input_weight

# what do you need this to do? 



# figure out an efficient way to store the weights of completed paths so that the system can prune.
paths_list=[]
def pathfinder(input_grid,input_moves=[],input_weight=0):
    # if len(input_grid)==5 and len(input_grid[0])==5:
    #     paths_list=[]
    right=[1]
    down=[3]
    diagonal=[2]
    current_weight=input_weight
    current_path = path(input_moves,current_weight)
    if len(input_grid)==5 and len(input_grid[0])==5:
        current_weight=input_grid[0][0]
    
    
    if len(input_grid[0]) == 1 and len(input_grid) == 1:      
        paths_list.append(current_path)

        
    
    #move diagonally possibility 
    if len(input_grid[0])>1 and len(input_grid)>1:
        grid_sans_row_and_column= [[ i for  i in input_grid[x][1:]] for x in range(len(input_grid))][1:]  
        # print("current weight:"+ str(current_weight))     
        diagonal_weight=current_weight+input_grid[1][1]
        # print("diagonal weight:"+str(diagonal_weight))
        move_diagonally=input_moves+diagonal
        pathfinder(grid_sans_row_and_column,move_diagonally,diagonal_weight)

    #move down possibility 
    if len(input_grid)>1 and len(input_grid[0])>0:
        grid_sans_row = input_grid[1:]
        down_weight=current_weight+input_grid[1][0]
        move_down=input_moves+down 
        pathfinder(grid_sans_row,move_down,down_weight)
    #move right possibility
    if len(input_grid[0])>1:
        grid_sans_column =  [[ i for  i in input_grid[x][1:]] for x in range(len(input_grid))]
        right_weight=current_weight+input_grid[0][1]
        move_right=input_moves+right
        pathfinder(grid_sans_column,move_right,right_weight)

    

def sort_paths(input_grid):
    pathfinder(input_grid)
    lightest =0
    lightest_path=[]
    heaviest = 0
    heaviest_path=[]
    for path in paths_list:
        if path.weight>heaviest:
            heaviest=path.weight
            heaviest_path=path.possible_path
        if path.weight<lightest or lightest==0:
            lightest=path.weight
            lightest_path=path.possible_path
    print("weightiest:"+str(heaviest))
    print(heaviest_path)
    print("lightest:"+str(lightest))
    print(lightest_path)
sort_paths(grid)


# for path in paths_list[50:]:
#     print(path.possible_path)


   # print(this_path.possible_path)


        # you need three branching recursions, a way to prune useless recursion, and a way to prune the grid by 1 row and 1 column each theoretical move.
